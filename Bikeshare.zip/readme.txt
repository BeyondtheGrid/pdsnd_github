stack overflow: finding .fill and min(), max()
stack overflow: Nan values
Career karma: local variable references
panda general documentation: fuctions
